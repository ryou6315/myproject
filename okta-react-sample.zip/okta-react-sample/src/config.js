
// eslint-disable-next-line
export default {
  oidc: {
    clientId: '0oa10uindrgzMgaeP698',
    issuer: 'https://trial-9596664.okta.com/oauth2/default',
    redirectUri: window.location.origin + '/login/callback',
    scopes: ['openid', 'profile', 'email', 'offline_access'],
  },
  resourceServer: {
    messagesUrl: 'http://localhost:8000/api/messages',
  },
};
