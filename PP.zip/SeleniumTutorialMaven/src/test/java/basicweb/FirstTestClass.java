package basicweb;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.junit.Test;
import org.openqa.selenium.chrome.ChromeDriver;

public class FirstTestClass {

	//public static void main(String[] args) {
	@Test
	public void test() {
		System.setProperty("webdriver.chrome.driver","D:\\12.个人开发\\6.Nec工作\\JMeter\\Selenium-Test\\libs\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.baidu.com");
		System.out.println(driver.getTitle());
		
		// 定位 textarea 元素
        WebElement textarea = driver.findElement(By.id("chat-textarea"));
        // 也可以用 CSS 定位：
        // WebElement textarea = driver.findElement(By.cssSelector("textarea.chat-input-textarea"));

        // 输入文字
        textarea.sendKeys("梵高的《星空》隐藏了什么物理公式");

        // 模拟回车
        textarea.sendKeys(Keys.ENTER);

        // 等待几秒查看效果
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

	}
 
}
