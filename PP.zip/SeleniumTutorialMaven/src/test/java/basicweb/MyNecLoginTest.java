package basicweb;

import org.openqa.selenium.By;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.junit.Test;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
public class MyNecLoginTest {

	//public static void main(String[] args) {
	@Test
	public void test() {
		ChromeOptions options = new ChromeOptions();
		// 绕过安全阻止
		//options.addArguments("--disable-blink-features=AutomationControlled");
		//options.addArguments("--disable-popup-blocking");
		//options.addArguments("--user-data-dir=/tmp/chrome-profile");
        
		System.setProperty("webdriver.chrome.driver","D:\\12.个人开发\\6.Nec工作\\JMeter\\Selenium-Test\\libs\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
			
		String username_pre = "nec_acquia01";
        String password_pre = "6nAJ59--2>dQ";
        String url = "https://" + username_pre + ":" + password_pre + "@neciexpodev.prod.acquia-sites.com/login";
        driver.get(url);
        
        
		driver.get("https://neciexpodev.prod.acquia-sites.com/login");
		System.out.println(driver.getTitle());
		
		// WebElement username = driver.findElement(By.id("okta-signin-username"));
		driver.manage().window().maximize();
		
		WebElement username = driver.findElement(By.id("okta-signin-username"));
	    username.sendKeys("outest02");


        // 通过 ID 定位密码框
        WebElement password = driver.findElement(By.id("okta-signin-password"));
        password.sendKeys("Godswl1981!");
        
        // 点击登录按钮
        WebElement loginButton = driver.findElement(By.id("okta-signin-submit"));
        loginButton.click();
        
        
        // 等待页面加载完成
        try { Thread.sleep(2000); } catch (InterruptedException e) {}

        // 定位并点击按钮
        WebElement btn = driver.findElement(By.cssSelector("#navbarToggleExternalContent2 > div > a:nth-child(1)"));
        btn.click();

        System.out.println("按钮已点击！");


        // 等待几秒查看效果
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

	}
 
}
